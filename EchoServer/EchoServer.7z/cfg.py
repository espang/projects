# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 22:22:26 2016

configuration for the echo server. 

@author: eikes
"""

address = ('localhost', 12345)